# -*- coding: iso-8859-1 -*-
"""
    MoinMoin - migration from base rev 1060400

    Nothing to do, we just return the new data dir revision.

    @copyright: 2008 by Thomas Waldmann
    @license: GNU GPL, see COPYING for details.
"""

def execute(script, data_dir, rev):
    return 1060500

